<?php

use Illuminate\Database\Seeder;

class Role_PermisoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // permisos para control-eventos
        // todo: hacer este arreglo solo de un numero de los id de los permisos
        $relaciones = [
            [3,13],
            [3,14],
            [3,15],
            [3,16],
            [3,17],

        ];
        $registros=[];
        // insertar los permisos del rol control-estado
        foreach($relaciones as $registro){
            $registros[] = [
                'IdRole'    => 3,               // id del rol control-eventos
                'IdPermiso' => $registro[1],    // del permiso que se le pone
                'CreatedBy' => 1,
                'UpdatedBy' => 1,
            ];
        }

        // insertar todos los permisso a el rol control-general
        for($i=1; $i<94; $i++){
            $registros[] = [
                'IdRole'    => 2,
                'IdPermiso' => $i,
                'CreatedBy' => 1,
                'UpdatedBy' => 1,
            ];
        }

        DB::table('Role_Permiso')->insert($registros);
    }
}
