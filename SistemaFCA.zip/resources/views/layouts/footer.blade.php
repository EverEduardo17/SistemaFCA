<footer class="footer mt-auto text-white text-center">
    <div class="container">
        &copy; 2020 Universidad Veracruzana. Todos los derechos reservados.
    </div>
</footer>