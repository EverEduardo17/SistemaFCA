<?php

namespace App\Http\Controllers;

use App\Models\DatosPersonales;
use Illuminate\Http\Request;

class DatosPersonalesController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(DatosPersonales $datosPersonales)
    {
        //
    }

    public function edit(DatosPersonales $datosPersonales)
    {
        //
    }

    public function update(Request $request, DatosPersonales $datosPersonales)
    {
        //
    }

    public function destroy(DatosPersonales $datosPersonales)
    {
        //
    }
}
