<?php

namespace App\Http\Controllers;

use App\Models\ExperienciaEducativa;
use Illuminate\Http\Request;

class ExperienciaEducativaController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(ExperienciaEducativa $experienciaEducativa)
    {
        //
    }

    public function edit(ExperienciaEducativa $experienciaEducativa)
    {
        //
    }

    public function update(Request $request, ExperienciaEducativa $experienciaEducativa)
    {
        //
    }

    public function destroy(ExperienciaEducativa $experienciaEducativa)
    {
        //
    }
}
