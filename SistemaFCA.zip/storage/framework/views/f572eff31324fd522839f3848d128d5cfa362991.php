<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('facultades.index')); ?>">Facultades</a></li>
        <li class="breadcrumb-item active" aria-current="page">Editar Facultad</li>
    </ol>
</nav>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8">Editar Facultad</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'facultades-listar')): ?>
                <a class="btn btn-primary col-4" href="<?php echo e(route('facultades.index')); ?>" role="button">Ver Facultades</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('facultades.update', $facultad)); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <label name="NombreFacultad">Nombre de la Facultad:</label>
                <input name="NombreFacultad" type="text" value="<?php echo e(old('NombreFacultad', $facultad->NombreFacultad)); ?>" class="form-control <?php $__errorArgs = ['NombreFacultad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. FCA Coatzacoalcos">
            </div>
            <div class="form-group">
                <label name="ClaveFacultad">Clave de la Facultad:</label>
                <input name="ClaveFacultad" class="form-control <?php $__errorArgs = ['ClaveFacultad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('ClaveFacultad', $facultad->ClaveFacultad)); ?>" maxlength="10" placeholder="Ej. 51301">
            </div>

            <button type="submit" class="btn btn-primary btn-block">Guardar</button>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'facultades-listar')): ?>
                <a href="<?php echo e(route('facultades.index')); ?>" class="btn btn-secondary btn-block">Cancelar</a>
            <?php endif; ?>
        </form>
        <hr>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'facultades-eliminar')): ?>
            <form method="POST" id="form-eliminar" action="<?php echo e(route('facultades.destroy', $facultad)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <a href="#" href="#" data-toggle="modal" data-target="#delete" class="btn btn-danger btn-block">Eliminar Permanentemente</a>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php echo $__env->make('facultades.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#delete').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/facultades/edit.blade.php ENDPATH**/ ?>