<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Tipo de Organizadores</li>
    </ol>
</nav>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <h5 class="card-title col-8">Tipo de Organizadores</h5>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'tipoorganizador-listar')): ?>
                    <a class="btn btn-success col-4" href="<?php echo e(route('tipoorganizador.create')); ?>" role="button">Agregar Tipo de Organizador</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <table id="table_tipoorganizador" class="table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tipoorganizadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($item->NombreTipoOrganizador); ?></th>
                            <td><?php echo e($item->DescripcionTipoOrganizador); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'tipoorganizador-editar')): ?>
                                    <a class="btn btn-primary btn-sm" href="#"
                                       data-toggle="modal" data-target="#editTipo"
                                       data-tipo="<?php echo e($item->IdTipoOrganizador); ?>"
                                       data-nombre="<?php echo e($item->NombreTipoOrganizador); ?>"
                                       data-descripcion="<?php echo e($item->DescripcionTipoOrganizador); ?>">Editar</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'tipoorganizador-eliminar')): ?>
                                    <a class="btn btn-danger btn-sm" href="#"
                                       data-toggle="modal" data-target="#deleteTipo"
                                       data-tipo="<?php echo e($item->IdTipoOrganizador); ?>">Eliminar</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo $__env->make('tipoorganizador.modal.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>

    <script>
        $(document).ready( function () {
            $('#table_tipoorganizador').DataTable();
        } );

        /*edit documento*/
        $('#editTipo').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('tipo');
            var nombre = button.data('nombre');
            var descripcion = button.data('descripcion');
            var modal = $(this);
            var actionStart = '<?php echo e(route('tipoorganizador.update', '')); ?>';
            modal.find('.modal-body form').attr('action', actionStart);
            var action = $("#form-editar-tipo").attr('action') + '/' + id;
            modal.find('.modal-body form').attr('action', action);
            modal.find('.modal-body input[name=NombreTipoOrganizador]').val(nombre);
            modal.find('.modal-body input[name=DescripcionTipoOrganizador]').val(descripcion);
        });
        /*delete documento*/
        $('#deleteTipo').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('tipo');
            var modal = $(this);
            var actionStart = '<?php echo e(route('tipoorganizador.destroy', '')); ?>';
            modal.find('.modal-body form').attr('action', actionStart);
            var action = $("#form-eliminar-tipo").attr('action') + '/' + id;
            modal.find('.modal-body form').attr('action', action);
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/tipoorganizador/index.blade.php ENDPATH**/ ?>