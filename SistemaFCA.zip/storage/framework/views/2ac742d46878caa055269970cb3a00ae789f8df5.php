<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('eventos.index')); ?>">Eventos</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($evento->NombreEvento ?? ""); ?></li>
    </ol>
</nav>
<div class="card">
        <div class="card-header">
            <div class="row d-flex align-items-center mr-2">
                <h4 class="mr-auto p-3"><?php echo e($evento->NombreEvento ?? ""); ?></h4>

                <div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'eventos-editar')): ?>
                        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editEvento">Editar</a>
                    <?php endif; ?>
                    <?php if($evento->EstadoEvento == "POR APROBAR"): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'eventoestado-aprobar')): ?>
                            <a href="#" class="btn btn-info" data-toggle="modal" data-target="#aprobarEvento">Aprobar</a>
                            <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#rechazarEvento">Rechazar</a>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($evento->EstadoEvento == "RECHAZADO"): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'eventoestado-editar')): ?>
                            <a href="#" class="btn btn-info" data-toggle="modal" data-target="#solicitarEvento">Solicitar aprobación</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group row">
                <label for="nombre" class="col-md-3 col-form-label text-md-right">Evento</label>
                <div class="col-md-8">
                    <input id="nombre" type="text" class="form-control" name="nombre" value="<?php echo e($evento->NombreEvento ?? ""); ?>" disabled>
                </div>
            </div>

            <div class="form-group row">
                <label for="descripcion" class="col-md-3 col-form-label text-md-right">Descripción</label>
                <div class="col-md-8">
                    <textarea id="descripcion" class="form-control" name="descripcion" rows="3" disabled><?php echo e($evento->DescripcionEvento ?? ""); ?></textarea>
                    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="estado" class="col-md-3 col-form-label text-md-right">Estado</label>
                <div class="col-md-8">
                    <input type="text" class="form-control"value="<?php echo e($evento->EstadoEvento); ?>" disabled>
                </div>
            </div>
            <?php if($evento->EstadoEvento == "RECHAZADO"): ?>
                <div class="form-group row">
                    <label for="estado" class="col-md-3 col-form-label text-md-right">Motivo de rechazo</label>
                    <div class="col-md-8">
                        <input type="text" class="form-control"value="<?php echo e($evento->Motivo); ?>" disabled>
                    </div>
                </div>
            <?php endif; ?>
            <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <br>
    <div class="card">
        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs" id="evento-list" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" href="#fechas" role="tab" aria-controls="fechas" aria-selected="true">Fechas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  href="#responsables" role="tab" aria-controls="responsables" aria-selected="false">Responsables</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#participantes" role="tab" aria-controls="participantes" aria-selected="false">Participantes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#documentos" role="tab" aria-controls="documentos" aria-selected="false">Documentos</a>
                </li>
            </ul>
        </div>
        <div class="card-body pt-0">
            <div class="tab-content mt-3">
                <div class="tab-pane active" id="fechas" role="tabpanel">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex align-items-center">
                                <h4 class="mr-auto pl-3">Fechas</h4>
                                <div class="btn-group" role="group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'fechaevento-crear')): ?>
                                        <button class="btn btn-success" data-toggle="modal" data-target="#addfecha" data-do="create">Agregar Fecha</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table id="table_eventos" class="display">
                                <thead>
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Inicio</th>
                                        <th>Fin</th>
                                        <th>Sede</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $evento_fecha_sede_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($efs->fechaEvento->InicioFechaEvento->format('d/m/Y') ?? ""); ?></td>
                                            <td><?php echo e($efs->fechaEvento->InicioFechaEvento->format('h:i A') ?? ""); ?></td>
                                            <td><?php echo e($efs->fechaEvento->FinFechaEvento->format('h:i A') ?? ""); ?></td>
                                            <td><?php echo e($efs->sedeEvento->NombreSedeEvento ?? ""); ?></td>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'fechaevento-editar')): ?>
                                                    <a class="btn btn-sm btn-primary" href="#" data-toggle="modal" data-target="#addfecha"
                                                       data-do="update" data-fecha="<?php echo e($efs->IdFechaEvento); ?>"
                                                       data-fechainicio="<?php echo e($efs->fechaEvento->InicioFechaEvento->format('d/m/Y')); ?>"
                                                       data-horainicio="<?php echo e($efs->fechaEvento->InicioFechaEvento->format('g:i A')); ?>"
                                                       data-horafin="<?php echo e($efs->fechaEvento->FinFechaEvento->format('g:i A')); ?>"
                                                       data-sedeevento="<?php echo e($efs->IdSedeEvento); ?>" >Editar</a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'fechaevento-eliminar')): ?>
                                                    <a class="btn btn-sm btn-danger" href="#" data-toggle="modal"
                                                       data-target="#deletefecha" data-fecha="<?php echo e($efs->IdFechaEvento); ?>">Eliminar</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane" id="responsables" role="tabpanel" aria-labelledby="responsables-tab">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex align-items-center">
                                <h4 class="mr-auto pl-3">Responsables</h4>
                                <div class="btn-group" role="group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'responsable-crear')): ?>
                                        <button class="btn btn-success" data-toggle="modal" data-target="#addTipoOrganizador">Agregar Responsable</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table id="table_responsable" class="display">
                                <thead>
                                <tr>
                                    <th>Responsable</th>
                                    <th>Rol</th>
                                    <th>Acciones</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $evento->organizador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responsable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($responsable->academico->usuario->name); ?></td>
                                        <td><?php echo e($responsable->tipo_organizador->NombreTipoOrganizador); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'responsable-eliminar')): ?>
                                                <a  class="btn btn-sm btn-danger" href="#" data-toggle="modal" data-target="#deleteTipoOrganizador"
                                                    data-tipoorganizador="<?php echo e($responsable->IdOrganizador); ?>">Eliminar</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane" id="participantes" role="tabpanel" aria-labelledby="participantes-tab">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex align-items-center">
                                <h4 class="mr-auto pl-3">Participantes</h4>
                                <div class="btn-group" role="group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'participantes-crear')): ?>
                                        <button class="btn btn-success" data-toggle="modal" data-target="#addParticipante">Agregar Participante</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table id="table_participante" class="display">
                                <thead>
                                    <tr>
                                        <th>No. de Personal</th>
                                        <th>Nombre del Académico</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $evento->academico_evento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ae): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($ae->academico->NoPersonalAcademico); ?></td>
                                            <td><?php echo e($ae->academico->usuario-> name); ?></td>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'participantes-eliminar')): ?>
                                                    <a class="btn btn-sm btn-danger" href="#" data-toggle="modal" data-target="#deleteParticipante"
                                                       data-participante="<?php echo e($ae->Id_Academico_Evento); ?>">Eliminar</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane" id="documentos" role="tabpanel" aria-labelledby="documentos-tab">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex align-items-center">
                                <h4 class="mr-auto pl-3">Documentos</h4>
                                <div class="btn-group" role="group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'documentos-crear')): ?>
                                        <button class="btn btn-success" data-toggle="modal" data-target="#addDocument">Agregar Documento</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table id="table_documentos" class="display">
                                <thead>
                                    <tr>
                                        <th>Nombre del Documento</th>
                                        <th>Descripción del Documento</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $evento->documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($documento->NombreDocumento); ?></td>
                                            <td><?php echo e($documento->DescripcionDocumento); ?></td>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'documentos-leer')): ?>
                                                    <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('documento.show', $documento->IdDocumento)); ?>">Descargar</a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'documentos-editar')): ?>
                                                    <a class="btn btn-sm btn-primary" href="#" data-toggle="modal" data-target="#editDocumento"
                                                       data-documento="<?php echo e($documento->IdDocumento); ?>"
                                                       data-nombre="<?php echo e($documento->NombreDocumento); ?>"
                                                       data-descripcion="<?php echo e($documento->DescripcionDocumento); ?>">Editar</a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'documentos-eliminar')): ?>
                                                    <a class="btn btn-sm btn-danger" href="#" data-toggle="modal" data-target="#deleteDocumento"
                                                       data-documento="<?php echo e($documento->IdDocumento); ?>">Eliminar</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('eventos.modals.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('eventos.modals.fecha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('eventos.modals.documento', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('eventos.modals.tipoorganizador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('eventos.modals.participante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('eventos.modals.eventoestado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/bootstrap3/css/bootstrap-mod.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datetimepicker/css/bootstrap-datetimepicker.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.blockUI.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/moment/min/moment-with-locales.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/datetimepicker/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script>
        $(document).on('click', '#agregarDocumentoCargando', function() {
            $('#addDocument').modal('hide');
            $.blockUI({
                message: 'Espere un momento...',
                css: {
                    border: 'none',
                    padding: '15px',
                    backgroundColor: '#000',
                    '-webkit-border-radius': '10px',
                    '-moz-border-radius': '10px',
                    opacity: .5,
                    color: '#fff'
                }
            });
        });

        $(document).ready( function () {
            $('#table_eventos').DataTable();
            $('#table_documentos').DataTable();
            $('#table_responsable').DataTable();
            $('#table_participante').DataTable();

        } );


        $('#evento-list a').on('click', function (e) {
            e.preventDefault();
            $(this).tab('show');
        })

        /*Eliminar Fechas*/
        $('#deletefecha').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var recipient = button.data('fecha');
            var modal = $(this);
            modal.find('.modal-body input[name=fechaEvento]').val(recipient);
        })

        //Modal Fechas
        $('#addfecha').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var recipient = button.data('fecha');
            var modal = $(this);
            var action = button.data('do');
            if( action == 'create' ){
                modal.find('.modal-title').text('Agregar fecha');
                modal.find('.modal-body input[name=fechaEvento]').val( 1 );
                modal.find('.modal-body input[name=_method]').val('post');
                modal.find('.modal-body form').attr('action', '<?php echo e(route('fechaEventos.store')); ?>');
                modal.find('.modal-footer button[type=submit]').text('Agregar');
                modal.find('#fechaInicio').val(null);
                modal.find('#horaInicio').val(null);
                modal.find('#horaFin').val(null);
                modal.find('#sede').val(null);
            }else if( action == 'update'){
                var fechaInicio = button.data('fechainicio');
                var horaInicio = button.data('horainicio');
                var horaFin = button.data('horafin');
                var sedeEvento = button.data('sedeevento');
                modal.find('.modal-title').text('Editar fecha');
                modal.find('.modal-body input[name=fechaEvento]').val(recipient);
                modal.find('.modal-body input[name=_method]').val('put');
                modal.find('.modal-body form').attr('action', '<?php echo e(route('fechaEventos.update')); ?>');
                modal.find('#fechaInicio').val(fechaInicio);
                modal.find('#horaInicio').val(horaInicio);
                modal.find('#horaFin').val(horaFin);
                modal.find('#sede').val(sedeEvento);
                modal.find('.modal-footer button[type=submit]').text('Editar');
            }
        })

        $('#editEvento').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })

        $('#addDocument').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })

        $('#solicitarEvento').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })

        $('#aprobarEvento').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })

        $('#rechazarEvento').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })

        /*Eliminar documento*/
        $('#deleteDocumento').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('documento');
            var modal = $(this);
            var action = $("#form-eliminar-documento").attr('action') + '/' + id;
            modal.find('.modal-body form').attr('action', action);
        })

        /*edit documento*/
        $('#editDocumento').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('documento');
            var nombre = button.data('nombre');
            var descripcion = button.data('descripcion');
            var modal = $(this);
            var action = $("#form-editar-documento").attr('action') + '/' + id;
            modal.find('.modal-body form').attr('action', action);
            modal.find('.modal-body input[name=NombreDocumento]').val(nombre);
            modal.find('.modal-body input[name=DescripcionDocumento]').val(descripcion);
        })

        $('#addTipoOrganizador').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })

        /*Eliminar tipoorganizador*/
        $('#deleteTipoOrganizador').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('tipoorganizador');
            var modal = $(this);
            var action = $("#form-eliminar-organizador").attr('action') + '/' + id;
            modal.find('.modal-body form').attr('action', action);
        })

        $('#addParticipante').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })

        /*Eliminar tipoorganizador*/
        $('#deleteParticipante').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('participante');
            var modal = $(this);
            var action = $("#form-eliminar-participante").attr('action') + '/' + id;
            modal.find('.modal-body form').attr('action', action);
        })


        /*Date Picker*/
        $('#fechaInicio').datetimepicker({
            locale: 'es',
            format: 'L'
        });

        $('#horaInicio').datetimepicker({
            format: 'LT'
        });

        $('#horaFin').datetimepicker({
            format: 'LT'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/eventos/show.blade.php ENDPATH**/ ?>