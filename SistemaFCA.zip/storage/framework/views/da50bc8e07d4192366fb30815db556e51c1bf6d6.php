<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('academias.index')); ?>">Academias</a></li>
        <li class="breadcrumb-item active" aria-current="page">Agregar Academia</li>
    </ol>
</nav>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8">Agregar Academia</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academias-listar')): ?>
                <a class="btn btn-primary col-4" href="<?php echo e(route('academias.index')); ?>" role="button">Ver Academias</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('academias.store')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <label name="NombreAcademia">Nombre de la Academia:</label>
                <input name="NombreAcademia" type="text" value="<?php echo e(old('NombreAcademia', $academia->NombreAcademia)); ?>" class="form-control <?php $__errorArgs = ['NombreAcademia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Academia de Informática.">

            </div>
            <div class="form-group">
                <label name="Coordinador">Docente Coordinador:</label>
                <select name="Coordinador" class="form-control <?php $__errorArgs = ['Coordinador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__currentLoopData = $coordinadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordinador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($coordinador->IdAcademico); ?>"><?php echo e($coordinador->usuario->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label name="DescripcionAcademia">Descripción de la Academia:</label>
                <textarea name="DescripcionAcademia" class="form-control <?php $__errorArgs = ['DescripcionAcademia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" placeholder="Ej. Academia de Informática de la FCA Coatzacoalcos."><?php echo e(old('DescripcionAcademia', $academia->DescripcionAcademia)); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Guardar</button>
            <a href="<?php echo e(route('academias.index')); ?>" class="btn btn-secondary btn-block">Cancelar</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/academias/create.blade.php ENDPATH**/ ?>