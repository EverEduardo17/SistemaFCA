<?php if( Session::has('flash') ): ?>
    <?php $__currentLoopData = Session::get('flash'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flash): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-<?php echo e($flash['type'] ?? 'success'); ?> alert-dismissible ml-3 mr-3" role="alert">
            <?php echo $flash['message'] ?? ''; ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/layouts/messages.blade.php ENDPATH**/ ?>