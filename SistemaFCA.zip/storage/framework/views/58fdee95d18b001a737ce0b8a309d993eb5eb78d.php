<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('eventos.index')); ?>">Eventos</a></li>
        <li class="breadcrumb-item active" aria-current="page">Agregar evento</li>
    </ol>
</nav>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8">Agregar Evento</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'eventos-listar')): ?>
                <a class="btn btn-primary col-4" href="<?php echo e(route('eventos.index')); ?>" role="button">Ver Eventos</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('eventos.store')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <label name="nombre">Nombre del Evento:</label>
                <input name="nombre" type="text" value="<?php echo e(old('nombre')); ?>" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Nuevo Evento">
            </div>

            <div class="form-group">
                <label name="descripcion">Descripción del Evento:</label>
                <input name="descripcion" type="text" value="<?php echo e(old('descripcion')); ?>" class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Descripción del Nuevo Evento Creado.">
            </div>
            <hr>
            <div class="form-group">
                <label for="fechaInicio">Fecha del Evento:</label>
                <input id="fechaInicio" type="text" class="form-control <?php $__errorArgs = ['fechaInicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fechaInicio" value="<?php echo e(old('fechaInicio')); ?>" placeholder="Día/Mes/Año">
            </div>

            <div class="form-group">
                <div class="form-row">
                    <div class="col">
                        <label for="horaInicio">Hora de Inicio:</label>
                        <input id="horaInicio" type="text" class="form-control  <?php $__errorArgs = ['horaInicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="horaInicio" value="<?php echo e(old('horaInicio')); ?>" placeholder="Hora de Inicio">
                    </div>
                    <div class="col">
                        <label for="horaInicio">Hora de Término:</label>
                        <input id="horaFin" type="text" class="form-control datetimepicker-input <?php $__errorArgs = ['horaFin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="horaFin" value="<?php echo e(old('horaFin')); ?>" placeholder="Hora de Término">
                    </div>
                </div>
            </div>
            <hr>
            <div class="form-group">
                <label name="sede">Sede del Evento:</label>
                <select name="sede" id="sede" class="form-control <?php $__errorArgs = ['sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sede->IdSedeEvento); ?>" <?php echo e(old('sede') == $sede->IdSedeEvento ? ' selected' : ''); ?>><?php echo e($sede->NombreSedeEvento); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Guardar</button>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'eventos-listar')): ?>
                <a href="<?php echo e(route('eventos.index')); ?>" class="btn btn-secondary btn-block">Cancelar</a>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('lib/bootstrap3/css/bootstrap-mod.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('lib/datetimepicker/css/bootstrap-datetimepicker.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="<?php echo e(asset('lib/moment/min/moment-with-locales.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('lib/datetimepicker/js/bootstrap-datetimepicker.min.js')); ?>"></script>
<script>
    $('#fechaInicio').datetimepicker({
        locale: 'es',
        format: 'L'
    });

    $('#horaInicio').datetimepicker({
        format: 'LT'
    });

    $('#horaFin').datetimepicker({
        format: 'LT'
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/eventos/create.blade.php ENDPATH**/ ?>