<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('academias.index')); ?>">Academias</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($academia->NombreAcademia); ?></li>
    </ol>
</nav>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <h5 class="card-title col-8"><?php echo e($academia->NombreAcademia); ?></h5>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academias-editar')): ?>
                    <a class="btn btn-primary col-4" href="<?php echo e(route('academias.edit', $academia)); ?>" role="button">Editar Academia</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-8">
                    <h6 class="card-title">Coordinador: <?php echo e($academia->coordinador->usuario->name); ?></h6>
                    <p class="card-text"><?php echo e($academia->DescripcionAcademia); ?></p>
                </div>
                <div class="col">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academia-academico-crear')): ?>
                        <a class="btn btn-success" href="#" data-toggle="modal" data-target="#addAcademicoAcademia" >Agregar integrate</a>
                    <?php endif; ?>
                </div>
            </div>
            <br>
            <br>
            <table class="table table-striped" id="table">
                <thead>
                    <tr>
                        <th>No. de Personal</th>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $academia->academico_academia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($item->academico->NoPersonalAcademico); ?></th>
                            <td><?php echo e($item->academico->usuario->name); ?></td>
                            <td><?php echo e($item->academico->usuario->email); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academia-academico-eliminar')): ?>
                                    <a class="btn btn-sm btn-danger" href="#" data-toggle="modal" data-target="#deleteAcademicoAcademia" data-academico="<?php echo e($item->Id_Academico_Academia); ?>">Eliminar</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo $__env->make('academias.models.delete-academico-academia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
    <script>
        $(document).ready( function () {
            $('#table').DataTable();
        } );

        /*Eliminar Acedemico*/
        $('#deleteAcademicoAcademia').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('academico');
            var modal = $(this);
            modal.find('.modal-body form').attr('action', '<?php echo e(route('deleteAcademicoAcademia', '')); ?>');
            var action = $("#form-eliminar-academico").attr('action') + '/' + id;
            modal.find('.modal-body form').attr('action', action);
        })

        /*Eliminar Acedemico*/
        $('#addAcademicoAcademia').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var modal = $(this);
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/academias/show.blade.php ENDPATH**/ ?>