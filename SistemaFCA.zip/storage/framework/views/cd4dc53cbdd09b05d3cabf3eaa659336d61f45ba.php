<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Facultades</li>
    </ol>
</nav>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8">Facultades</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'facultades-crear')): ?>
                <a class="btn btn-success col-4" href="<?php echo e(route('facultades.create')); ?>" role="button">Agregar Facultad</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-striped" id="table_facultades">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Clave</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $facultades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($item->NombreFacultad); ?></th>
                    <td><?php echo e($item->ClaveFacultad); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'facultades-editar')): ?>
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('facultades.edit', $item)); ?>">Editar</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
<script>
    $(document).ready(function() {
        $('#table_facultades').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/facultades/index.blade.php ENDPATH**/ ?>