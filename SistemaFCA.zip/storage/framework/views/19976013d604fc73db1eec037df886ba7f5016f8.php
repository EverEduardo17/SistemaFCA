<div class="modal fade" id="deleteAcademicoAcademia" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h5 class="modal-title text-white" id="exampleModalLabel">Eliminar Académico</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Usted está por eliminar un académico de la academia: <br> <strong> <?php echo e($academia->NombreAcademia); ?></strong></p>
                <h5>¿Desea continuar?</h5>
                <form id="form-eliminar-academico" method="post" action="<?php echo e(route('deleteAcademicoAcademia', '')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <button type="submit" class="btn btn-danger" form="form-eliminar-academico">Eliminar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addAcademicoAcademia" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-success">
                <h5 class="modal-title text-white" id="exampleModalLabel">Agregar Integrante</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="form-add-academico" action="<?php echo e(route('academiaacademico.store')); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <input type="hidden" name="academia" value="<?php echo e($academia->IdAcademia); ?>">
                    <div class="form-group">
                        <label>Agrega un académico a la academia:<br> <strong> <?php echo e($academia->NombreAcademia); ?></strong></label>
                        <br>
                        <label name="docente">Docente:</label>
                        <select name="docente" class="form-control <?php $__errorArgs = ['docente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__currentLoopData = $academicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($academico->IdAcademico); ?>"><?php echo e($academico->usuario->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <button type="submit" class="btn btn-success" form="form-add-academico">Agregar</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/academias/models/delete-academico-academia.blade.php ENDPATH**/ ?>