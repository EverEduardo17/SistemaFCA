
<?php $__env->startSection('breadcrumb'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('cohortes.mostrarCohorte')); ?>">Gestión de Estudiantes</a></li>
        <li class="breadcrumb-item active" aria-current="page">Cohorte <?php echo e($nombreCohorte); ?></li>
    </ol>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
<?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h4 class="card-title col-8">Gestión de Estudiantes</h4>
        </div>
    </div>
    <div class="card-body">
        <div class="contenedor-botones justify-content-center align-items-center">
            <a class="btn btn-outline-dark mr-2" href="#"> <em class="fas fa-eye"></em> Ver Cohorte</a>
            <a href="<?php echo e(route('cohortes.agregarEstudiante',$nombreCohorte)); ?>" class="btn btn-outline-dark mr-2"><em
                    class="fas fa-plus-circle"></em> Agregar Estudiante</a>
            <a class="btn btn-outline-dark mr-2" href="#"><em class="fas fa-pen"></em> Editar Estudiante</a>
            <a class="btn btn-outline-dark mr-2" href="#"><em class="fas fa-minus-circle"></em> Dar de Baja
                Estudiante</a>
        </div>
        <h5 class="py-2">Cohortes</h5>
        <div class="testimonial-group mx-3 my-2">
            <div class="row text-center text-white">
                <?php $__currentLoopData = $cohortes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cohorte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="col-s-4 btn mb-3 <?php if($cohorte->IdCohorte == $idCohorte): ?>btn-primary <?php elseif($cohorte->IdCohorte <> $idCohorte): ?>btn-outline-primary <?php endif; ?>"
                    href="<?php echo e(route('cohortes.show', $cohorte->NombreCohorte)); ?>"><?php echo e($cohorte->NombreCohorte); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <hr class="my-4">
        <h5 class="py-2">Grupos</h5>
        <ul class="nav nav-tabs" id="nav-tab" role="tablist">
            <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item" role="presentation">
                <a class="btn-outline-primary nav-link 
                <?php if($programa->AcronimoProgramaEducativo == $programas[0]->AcronimoProgramaEducativo): ?> active" <?php endif; ?>
                    id="nav-<?php echo e($programa->AcronimoProgramaEducativo); ?>-tab" data-toggle="tab"
                    href="#nav-<?php echo e($programa->AcronimoProgramaEducativo); ?>" role="tab"
                    aria-controls="nav-<?php echo e($programa->AcronimoProgramaEducativo); ?>"
                    aria-selected="<?php if($programa->AcronimoProgramaEducativo == $programas[0]->AcronimoProgramaEducativo): ?>true"
                    <?php endif; ?> <?php if($programa->AcronimoProgramaEducativo != $programas[0]->AcronimoProgramaEducativo): ?>"false"
                    <?php endif; ?> ><?php echo e($programa->AcronimoProgramaEducativo); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="tab-content" id="nav-tabContent">
            <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="py-3 tab-pane fade <?php if($programa->AcronimoProgramaEducativo == $programas[0]->AcronimoProgramaEducativo): ?>show active <?php endif; ?>"
                id="nav-<?php echo e($programa->AcronimoProgramaEducativo); ?>" role="tabpanel"
                aria-labelledby="nav-<?php echo e($programa->AcronimoProgramaEducativo); ?>-tab">
                <div class="row">
                    <div class="col-md-12">
                        <div class="d-flex align-items-center mb-0 pb-0">
                            <h5 class="mr-auto pl-3"><?php echo e($programa->AcronimoProgramaEducativo); ?> - <?php echo e($nombreCohorte); ?></h5>
                            <div class="btn-group" role="group">
                                <button class="btn btn-success" data-toggle="modal" data-target="#create">Agregar
                                    Grupo</button>
                            </div>
                        </div>
                        <hr>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive-xl">
                        <table class="table table-striped table-hover"
                            id="table_<?php echo e($programa->AcronimoProgramaEducativo); ?>">
                            <caption>Grupos registrados en el sistema para el programa
                                <?php echo e($programa->AcronimoProgramaEducativo); ?> en
                                el cohorte <?php echo e($nombreCohorte); ?>.</caption>
                            <thead class="bg-table">
                                <tr class="text-white">
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Estudiantes Activos</th>
                                    <th scope="col">Estudiantes Inactivos</th>
                                    <th scope="col">Total de estudiantes</th>
                                    <th scope="col">Último periodo activo</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($grupo->IdProgramaEducativo == $programa->IdProgramaEducativo): ?>
                                <tr>
                                    <?php $cantidades = app('App\Http\Controllers\GrupoController'); ?>
                                    <th scope="row"><?php echo e($grupo->NombreGrupo); ?></th>

                                    <td><?php if($cantidades->contarEstudiantes($grupo->IdGrupo)[0] == null): ?>0
                                        <?php elseif($cantidades->contarEstudiantes($grupo->IdGrupo)[0] <>
                                            null): ?> <?php echo e($cantidades->contarEstudiantes($grupo->IdGrupo)[0]); ?><?php endif; ?></td>
                                    <td><?php if($cantidades->contarEstudiantes($grupo->IdGrupo)[1] == null): ?>0
                                        <?php elseif($cantidades->contarEstudiantes($grupo->IdGrupo)[1] <>
                                            null): ?> <?php echo e($cantidades->contarEstudiantes($grupo->IdGrupo)[1]); ?><?php endif; ?></td>
                                    <td><strong><?php echo e($cantidades->contarEstudiantes($grupo->IdGrupo)[0]+ $cantidades->contarEstudiantes($grupo->IdGrupo)[1]); ?></strong>
                                    </td>
                                    <td><?php echo e($grupo->periodoActivo->NombrePeriodo); ?></td>
                                    <td class="btn-group btn-group-sm px-3">
                                        <a class="btn btn-outline-primary btn-sm"
                                            href="<?php echo e(route('cohortes.mostrarGrupo', [$nombreCohorte, $grupo->NombreGrupo])); ?>">Visualizar</a>
                                        <a class="btn btn-info btn-sm"
                                            href="<?php echo e(route('grupos.show', $grupo)); ?>">Detalles</a>
                                        <form method="POST" id="form-eliminar"
                                            action="<?php echo e(route('grupos.destroy', $grupo)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <a href="#" data-toggle="modal" data-target="#delete"
                                                class="btn btn-danger btn-sm">Eliminar</a>
                                        </form>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<?php echo $__env->make('grupos.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('grupos.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
<script>
    //TODO Checar, cuando se agreguen nuevos PE va a fallar.
    $(document).ready(function() {
        $('#table_LA').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
            }
        });
        $('#table_LC').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
            }
        });
        $('#table_LGDN').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
            }
        });
        $('#table_LIS').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
            }
        });
        $('#table_LSCA').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
            }
        });
    });
</script>
<script>
    $('#delete').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
    })
    $('#create').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var modal = $(this);
    })
  
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/cohorte/show.blade.php ENDPATH**/ ?>