<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('sedeEventos.index')); ?>">Sedes</a></li>
    <li class="breadcrumb-item active" aria-current="page">Agregar Sede</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">
    <div class="row">
      <h5 class="card-title col-8">Agregar Sede</h5>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'sedes-listar')): ?>
            <a class="btn btn-primary col-4" href="<?php echo e(route('sedeEventos.index')); ?>" role="button">Ver Sedes</a>
        <?php endif; ?>
    </div>
  </div>
  <div class="card-body">

    <form method="POST" action="<?php echo e(route('sedeEventos.store')); ?>" autocomplete="off">
      <?php echo csrf_field(); ?>
      <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="form-group">
        <label name="NombreSedeEvento">Nombre de la Sede:</label>
        <input name="NombreSedeEvento" type="text" class="form-control <?php $__errorArgs = ['NombreSedeEvento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('NombreSedeEvento')); ?>" placeholder="Ej. LABLIS">
      </div>
      <div class="form-group">
        <label name="DescripcionSedeEvento">Descripción de la sede:</label>
        <input name="DescripcionSedeEvento" class="form-control <?php $__errorArgs = ['DescripcionSedeEvento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('DescripcionSedeEvento')); ?>" placeholder="Ej. Centro de cómputo de LIS">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Guardar</button>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'sedes-listar')): ?>
            <a href="<?php echo e(route('sedeEventos.index')); ?>" class="btn btn-secondary btn-block">Cancelar</a>
        <?php endif; ?>
    </form>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/sedeEvento/create.blade.php ENDPATH**/ ?>