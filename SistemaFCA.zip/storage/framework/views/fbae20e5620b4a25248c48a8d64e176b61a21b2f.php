<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('tipoorganizador.index')); ?>">Tipo de Organizadores</a></li>
        <li class="breadcrumb-item active" aria-current="page">Agregar Tipo de Organizador</li>
    </ol>
</nav>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8">Agregar Tipo de Organizador</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'tipoorganizador-listar')): ?>
                <a class="btn btn-primary col-4" href="<?php echo e(route('tipoorganizador.index')); ?>" role="button">Ver Tipo de Organizadores</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('tipoorganizador.store')); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <label name="NombreTipoOrganizador">Nombre del Tipo de Organizador:</label>
                <input name="NombreTipoOrganizador" type="text" value="<?php echo e(old('NombreTipoOrganizador')); ?>" class="form-control <?php $__errorArgs = ['NombreTipoOrganizador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Responsable">
            </div>
            <div class="form-group">
                <label name="DescripcionTipoOrganizador">Descripción del Tipo de Organizador</label>
                <input name="DescripcionTipoOrganizador" type="text" value="<?php echo e(old('DescripcionTipoOrganizador')); ?>" class="form-control <?php $__errorArgs = ['DescripcionTipoOrganizador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Representante ante la facultad del evento. ">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Guardar</button>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'tipoorganizador-listar')): ?>
                <a href="<?php echo e(route('tipoorganizador.index')); ?>" class="btn btn-secondary btn-block">Cancelar</a>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/tipoorganizador/create.blade.php ENDPATH**/ ?>