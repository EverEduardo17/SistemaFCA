<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Académicos</li>
    </ol>
</nav>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8">Académicos</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academicos-crear')): ?>
                <a class="btn btn-success col-4" href="<?php echo e(route('academicos.create')); ?>" role="button">Agregar Académico</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-striped" id="table_academicos">
            <thead>
                <tr>
                    <th>No. Personal</th>
                    <th>Nombre Completo</th>
                    <th>Correo electrónico</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $academicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($academico->NoPersonalAcademico ?? ""); ?></td>
                    <td>
                        <?php echo e($academico->usuario->datosPersonales->ApellidoPaternoDatosPersonales ?? "-"); ?>

                        <?php echo e($academico->usuario->datosPersonales->ApellidoMaternoDatosPersonales ?? "-"); ?>

                        <?php echo e($academico->usuario->datosPersonales->NombreDatosPersonales ?? ""); ?>

                    </td>
                    <td><?php echo e($academico->usuario->email ?? ""); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academicos-leer')): ?>
                            <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('academicos.show', $academico)); ?>">Detalles</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academicos-editar')): ?>
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('academicos.edit', $academico)); ?>">Editar</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academicos-eliminar')): ?>
                                <a class="btn btn-danger btn-sm" href="#"
                                   data-toggle="modal" data-target="#deleteAcademico"
                                   data-academico="<?php echo e($academico->IdAcademico); ?>">Eliminar</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="modal fade" id="deleteAcademico" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h5 class="modal-title text-white" id="exampleModalLabel">Eliminar Academico</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Usted está por eliminar un academico.</p>
                <h5>¿Desea continuar?</h5>
                <small class="text-danger"><-- Esta acción no se puede deshacer --></small>
                <form id="form-eliminar-academico" method="post" action="<?php echo e(route('academicos.destroy', '')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="continuar">Cerrar</button>
                <button type="submit" class="btn btn-danger" form="form-eliminar-academico">Eliminar</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
<script>
    $(document).ready(function() {
        $('#table_academicos').DataTable();
    });
    $('#deleteAcademico').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var id = button.data('academico');
        var modal = $(this);
        var actionStart = '<?php echo e(route('academicos.destroy', '')); ?>';
        modal.find('.modal-body form').attr('action', actionStart);
        var action = $("#form-eliminar-academico").attr('action') + '/' + id;
        modal.find('.modal-body form').attr('action', action);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/academicos/index.blade.php ENDPATH**/ ?>