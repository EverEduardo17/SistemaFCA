
<?php $__env->startSection('breadcrumb'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Gestión de Grupos</li>
    </ol>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8"><strong>Gestión de Grupos</strong></h5>
            <a class="btn btn-success col-4" href="<?php echo e(route('grupos.create')); ?>" role="button">Agregar Grupo</a>
        </div>
    </div>
    <div class="card-body">

        <div class="table-responsive-xl">
            <table class="table table-striped table-hover" id="table_sede">
                <caption>Grupos registrados en el sistema.</caption>
                <thead class="bg-table">
                    <tr class="text-white">
                        <th scope="col" class="border-right">Nombre</th>
                        <th scope="col" class="border-right">Programa Educativo</th>
                        <th scope="col" class="border-right">Cohorte de pertenencia</th>
                        <th scope="col" class="border-right">Estudiantes activos</th>
                        <th scope="col" class="border-right">Total de estudiantes</th>
                        <th scope="col" class="border-right">Último periodo activo</th>
                        <th scope="col" class="border-right">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row" class="border-right"><?php echo e($grupo->NombreGrupo); ?></th>
                        <td class="border-right"><?php echo e($grupo->programaEducativo->AcronimoProgramaEducativo); ?></td>
                        <td class="border-right"><?php echo e($grupo->cohorte->NombreCohorte); ?></td>
                        <?php $estudiantes = app('App\Http\Controllers\GrupoController'); ?>
                            <td class="border-right"><?php echo e($estudiantes->contarEstudiantes($grupo->IdGrupo)[0]); ?></td>
                            <td class="border-right"><strong><?php echo e($estudiantes->contarEstudiantes($grupo->IdGrupo)[0] + $estudiantes->contarEstudiantes($grupo->IdGrupo)[1]); ?></strong></td>
                        <td class="border-right"><?php echo e($grupo->periodoActivo->NombrePeriodo); ?></td>
                        <td class="btn-group btn-group-sm px-3">
                            <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('grupos.show', $grupo)); ?>">Detalles</a>
                            <a class="btn btn-sm btn-danger" href="#" data-toggle="modal" data-target="#delete" data-id="<?php echo e($grupo->IdGrupo); ?>">Eliminar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php echo $__env->make('grupos.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
<script>
    $(document).ready(function() {
        $('#table_sede').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json",
            }

        });
    });
</script>
<script>
    /*Eliminar Grupo*/
    $('#delete').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var modal = $(this);
        var action = $("#form-eliminar-grupo").attr('action') + '/' + id;
        modal.find('.modal-body form').attr('action', action);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/grupos/index.blade.php ENDPATH**/ ?>