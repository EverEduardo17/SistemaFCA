<div class="modal fade" id="addfecha" tabindex="-1" role="dialog" aria-labelledby="fechaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-success">
                <h5 class="modal-title text-white" id="fechaModalLabel">Agregar fecha</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="form-fecha" action="" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <input type="hidden" name="_method" value="">
                    <input type="hidden" name="evento" value="<?php echo e($evento->IdEvento); ?>">
                    <input type="hidden" name="fechaEvento" value="">

                    <div class="form-group">
                        <label for="fechaInicio" class="col-form-label">Fecha del evento:</label>
                        <input id="fechaInicio" type="text" class="form-control <?php $__errorArgs = ['fechaInicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fechaInicio" value="<?php echo e(old('fechaInicio')); ?>" placeholder="Día/Mes/Año">
                    </div>

                    <div class="form-group">
                        <label for="horaInicio" class="col-form-label">Hora de inicio:</label>
                        <input id="horaInicio" type="text" class="form-control  datetimepicker-input <?php $__errorArgs = ['horaInicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="horaInicio" value="<?php echo e(old('horaInicio')); ?>" placeholder="Hora de Inicio">
                    </div>

                    <div class="form-group">
                        <label for="horaFin" class="col-form-label">Hora de término:</label>
                        <input id="horaFin" type="text" class="form-control datetimepicker-input <?php $__errorArgs = ['horaFin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="horaFin" value="<?php echo e(old('horaFin')); ?>" placeholder="Hora de Término">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Sede</label>
                        <select class="form-control <?php $__errorArgs = ['sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sede" name="sede">
                            <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sede->IdSedeEvento); ?>" <?php echo e(old('sede') == $sede->IdSedeEvento ? ' selected' : ''); ?>><?php echo e($sede->NombreSedeEvento); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <button type="submit" class="btn btn-success" form="form-fecha">Agregar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="deletefecha" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger">
                <h5 class="modal-title text-white" id="exampleModalLabel">Eliminar Fecha</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Usted está por eliminar una fecha del evento.</p>
                <h5>¿Desea continuar?</h5>
                <small class="text-danger"><-- Esta acción no se puede deshacer --></small>
                <form id="form-eliminar-fecha" method="post" action="<?php echo e(route('fechaeventos_delete')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <input type="hidden" name="fechaEvento">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <button type="submit" class="btn btn-danger" form="form-eliminar-fecha">Eliminar</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/eventos/modals/fecha.blade.php ENDPATH**/ ?>