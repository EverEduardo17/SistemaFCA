

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $opciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4">
                <br />
                <div class="card ">
                    <div class="card-header card text-center border-light  text-white" style="background: <?php echo e($item['background']); ?>"><?php echo e($item['titulo']); ?></div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $item['operaciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"><a href="<?php echo e(url($item['enlace'].'/'.$operacion['enlace'])); ?>"><?php echo e($operacion['titulo']); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/home.blade.php ENDPATH**/ ?>