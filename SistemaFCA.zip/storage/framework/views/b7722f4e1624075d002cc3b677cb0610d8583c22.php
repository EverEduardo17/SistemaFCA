<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Academias</li>
    </ol>
</nav>
<div class="card">
    <div class="card-header">
        <div class="row">
            <h5 class="card-title col-8">Academias</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academias-crear')): ?>
                <a class="btn btn-success col-4" href="<?php echo e(route('academias.create')); ?>" role="button">Agregar Academia</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-striped" id="table_academias">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Coordinador</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $academias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($item->NombreAcademia); ?></th>
                    <td><?php echo e($item->DescripcionAcademia); ?></td>
                    <td><?php echo e($item->coordinador->usuario->name); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academias-leer')): ?>
                            <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('academias.show', $item)); ?>">Detalles</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'academias-editar')): ?>
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('academias.edit', $item)); ?>">Editar</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
<script>
    $(document).ready(function() {
        $('#table_academias').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/academias/index.blade.php ENDPATH**/ ?>