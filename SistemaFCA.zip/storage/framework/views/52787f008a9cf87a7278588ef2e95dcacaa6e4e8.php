<div class="modal fade" id="editEvento" tabindex="-1" role="dialog" aria-labelledby="fechaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="fechaModalLabel">Editar Evento</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="form-editar-evento" action="<?php echo e(route('eventos.update', $evento->IdEvento)); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="id" id="id">
                    <?php echo $__env->make('layouts.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form-group">
                        <label name="NombreEvento">Nombre del Evento:</label>
                        <input name="NombreEvento" value="<?php echo e(old('NombreEvento', $evento->NombreEvento)); ?>" type="text" class="form-control <?php $__errorArgs = ['NombreEvento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Nuevo Evento Creado">
                    </div>
                    <div class="form-group">
                        <label name="DescripcionEvento">Descripción del Evento:</label>
                        <textarea name="DescripcionEvento" class="form-control <?php $__errorArgs = ['DescripcionEvento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" placeholder="Ej. Descripción del evento creado."><?php echo e(old('DescripcionEvento', $evento->DescripcionEvento)); ?></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <button type="submit" class="btn btn-primary" form="form-editar-evento">Actualizar</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/eventos/modals/edit.blade.php ENDPATH**/ ?>