<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Eventos</li>
    </ol>
</nav>
<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-3 text-center">
            <h4>Fechas de Eventos</h4>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-3 col-md-4 mb-3 text-center">
            <hr>
            <div id="dateStart" class="ui-datepicker-div"></div>
            <hr>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'eventos-crear')): ?>
                <a class="btn btn-primary btn-lg" href="<?php echo e(route('eventos.create')); ?>">Registrar un evento</a>
            <?php endif; ?>
        </div>
        <div class="col-lg-9 col-md-8">
            <table id="table_eventos" class="display">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Nombre</th>
                        <th>Sede</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $evento_fecha_sede_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($efs->fechaEvento->InicioFechaEvento ?? ""); ?></td>
                        <td><?php echo e($efs->evento->NombreEvento ?? ""); ?></td>
                        <td><?php echo e($efs->sedeEvento->NombreSedeEvento ?? ""); ?></td>
                        <td><?php echo e($efs->evento->EstadoEvento ?? ""); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('havepermiso', 'eventos-leer')): ?>
                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('eventos.show', [$efs->IdEvento])); ?>"> Detalles</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/datatables/css/jquery.dataTables.min.css')); ?>" />
<!-- Datepicker Files -->
<link rel="stylesheet" href="<?php echo e(asset('lib/datePicker/css/bootstrap-datepicker3.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('lib/datePicker/css/bootstrap-datepicker3.standalone.min.css')); ?>">
<style>
    .ui-datepicker-div {
        width: 220px;
        margin-left: auto;
        margin-right: auto;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('lib/datatables/js/jquery.dataTables.min.js')); ?>" defer></script>
<!-- DatePicker -->
<script src="<?php echo e(asset('lib/datePicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/datePicker/locales/bootstrap-datepicker.es.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        $('#table_eventos').DataTable();
    });

    $('#dateStart').datepicker({
        format: "dd/mm/yyyy",
        maxViewMode: 2,
        language: "es"
    }).on('changeDate', function(e) {
        window.location.href = "<?php echo e(route('eventos.index')); ?>" +
            "/" + e.date.getFullYear() +
            "/" + (e.date.getMonth() + 1) +
            "/" + e.date.getDate();
        //console.log(e.date.toISOString().slice(0,10) );
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SistemaFCA\resources\views/eventos/index.blade.php ENDPATH**/ ?>